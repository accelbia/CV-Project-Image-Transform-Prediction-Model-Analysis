from transforms.fourier import fourier_transform
fourier_transform('Hi')
# fourier_transform('path')